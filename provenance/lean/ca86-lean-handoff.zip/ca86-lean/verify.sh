#!/usr/bin/env bash
set -euo pipefail
cd -- "$(dirname -- "${BASH_SOURCE[0]}")"

# Prefer an explicit bin directory, then this machine's pinned local toolchain.
if [[ -n "${LEAN_BIN:-}" ]]; then
  export PATH="$LEAN_BIN:$PATH"
elif [[ -x "$HOME/.local/share/lean/toolchains/lean-4.28.0-linux/bin/lean" ]]; then
  export PATH="$HOME/.local/share/lean/toolchains/lean-4.28.0-linux/bin:$PATH"
elif [[ -x "$HOME/.elan/bin/lean" ]]; then
  export PATH="$HOME/.elan/bin:$PATH"
fi
unset PYTHONOPTIMIZE
mkdir -p logs
exec > >(tee logs/verify.log) 2>&1
lean --version
[[ "$(lean -V)" == "4.28.0" ]]
python3 generate.py --check
python3 - <<'PY'
from pathlib import Path
import re
files = [Path('CA86.lean'), Path('Audit.lean'), *Path('CA86').rglob('*.lean')]
for path in files:
    assert not re.search(r'\b(sorry|sorryAx|admit|axiom|unsafe|native_decide)\b', path.read_text()), path
print(f'Source audit passed: {len(files)} Lean files; no forbidden proof mechanisms.')
PY

# Delete local outputs, ensuring every project proof is checked anew.
lake clean
python3 measure.py logs/build-metrics.json lake --wfail build CA86 CA86.Negative
python3 measure.py logs/audit-metrics.json lake env lean -j1 -t0 Audit.lean | tee logs/axioms.log

# Replay all declarations, including imports, in a fresh Lean kernel environment.
python3 measure.py logs/replay-metrics.json lake env leanchecker --fresh CA86

if lake env lean -j1 tests/NegativeMustFail.lean > logs/negative-control.log 2>&1; then
  echo 'ERROR: invalid negative control was accepted.'
  exit 1
fi
cat logs/negative-control.log
python3 - <<'PY'
from pathlib import Path
audit = Path('logs/axioms.log').read_text()
assert 'sorryAx' not in audit and 'ofReduceBool' not in audit
expected = {
    'checkPair_sound': '[propext, Quot.sound]',
    'ca86_covering': '[propext, Quot.sound]',
    'ca86_existence': '[propext, Quot.sound]',
    'CAN_3_40_3_le_86': '[propext, Classical.choice, Quot.sound]',
    'CAN_3_40_3_spec': '[propext, Classical.choice, Quot.sound]',
    'zeroArray_not_covering': '[propext]',
    'zeroArray_checker_rejected': '[propext]',
}
for name, axioms in expected.items():
    assert f"'CA86.{name}' depends on axioms: {axioms}" in audit, name
negative = Path('logs/negative-control.log').read_text()
assert 'Tactic `decide` proved that the proposition' in negative and 'is false' in negative
print('Axiom audit and expected negative-control rejection passed.')
PY
sha256sum CA_86_3_40_3.txt
echo 'VERIFICATION PASSED: clean build, kernel replay, axiom audit, and negative control.'
