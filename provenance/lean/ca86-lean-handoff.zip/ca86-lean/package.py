#!/usr/bin/env python3
"""Create a source-only handoff with build evidence and an integrity manifest."""
from pathlib import Path
import hashlib
import zipfile

root = Path(__file__).resolve().parent
names = [
    '.gitignore', 'CA86.lean', 'Audit.lean', 'CA_86_3_40_3.txt',
    'generate.py', 'measure.py', 'verify.sh', 'package.py',
    'lean-toolchain', 'lakefile.toml', 'lake-manifest.json',
    'README.md', 'HANDOFF.md',
]
files = [root / name for name in names]
for directory in ['CA86', 'tests', 'logs']:
    files.extend(path for path in (root / directory).rglob('*') if path.is_file())
files.sort()
manifest = root / 'SHA256SUMS'
manifest.write_text(''.join(
    f'{hashlib.sha256(path.read_bytes()).hexdigest()}  {path.relative_to(root)}\n'
    for path in files
))
files.append(manifest)
archive = root / 'ca86-lean-handoff.zip'
with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as bundle:
    for path in files:
        bundle.write(path, Path('ca86-lean') / path.relative_to(root))
with zipfile.ZipFile(archive) as bundle:
    assert bundle.testzip() is None
    for path in files:
        assert bundle.read(str(Path('ca86-lean') / path.relative_to(root))) == path.read_bytes()
digest = hashlib.sha256(archive.read_bytes()).hexdigest()
(root / 'ca86-lean-handoff.zip.sha256').write_text(f'{digest}  {archive.name}\n')
print(f'{archive}: {archive.stat().st_size:,} bytes, {len(files)} files')
print(f'SHA-256: {digest}')
